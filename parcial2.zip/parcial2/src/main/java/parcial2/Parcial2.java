

package parcial2;

/**
 *
 * @author USUARIO
 */
public class Parcial2 {

    public static void main(String[] args) {
      conexion.conectarfirebase();
    }
}
